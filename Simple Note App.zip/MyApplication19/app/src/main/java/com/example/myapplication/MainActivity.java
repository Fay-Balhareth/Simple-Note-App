package com.example.myapplication;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements NoteAdapter.OnNoteClickListener {
    private RecyclerView recyclerView;
    private NoteAdapter noteAdapter;
    private ArrayList<Note> noteList;
    private Button addButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        addButton = findViewById(R.id.addButton);
        noteList = new ArrayList<>();
        noteAdapter = new NoteAdapter(noteList);
        noteAdapter.setOnNoteClickListener(this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(noteAdapter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startNewNoteActivity();
            }
        });
    }

    private void startNewNoteActivity() {
        Intent intent = new Intent(MainActivity.this, NewNoteActivity.class);
        startActivityForResult(intent, 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            String title = data.getStringExtra("title");
            String description = data.getStringExtra("description");
            Note newNote = new Note(title, description);
            noteList.add(newNote);
            noteAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onDeleteClick(int position) {
        noteList.remove(position);
        noteAdapter.notifyItemRemoved(position);
    }

    public void addNote(View view) {
        Intent intent = new Intent(MainActivity.this, NewNoteActivity.class);
        startActivityForResult(intent, 1);
    }
}